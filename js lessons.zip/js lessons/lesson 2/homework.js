let apple = 0
while (apple < 101) {
    console.log(apple)
    apple++ 
}

//

let sum = 0;
for (let i = 1; i <= 100; i++) {
    sum += i;
}
console.log("Сума чисел від 1 до 100: " + sum);


///


let sum2 = 0;
let i = 1;
while (i <= 100) {
    sum2 += i;
    i++;
}
console.log("Сума чисел від 1 до 100: " + sum2);

//

let sum3 = 0;
let i2 = 2 ; 
while (i2 <= 100 ) { 
    sum3 += i2;
    i2++;
}